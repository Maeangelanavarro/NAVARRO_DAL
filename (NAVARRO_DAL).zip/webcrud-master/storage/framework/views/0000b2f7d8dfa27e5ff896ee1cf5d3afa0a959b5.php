<?php $__env->startSection('content'); ?>
    <div class="col-md-6 offset-md-3 p-5">
        <div class="pull-left">
            <h2 class="text-center"> Show</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-warning" href="<?php echo e(route('students.index')); ?>">Go Back </a>
        </div>

        <div class="row">
            <div class="col mt-5">
                <div class="card p-5 alert-success">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong>Captain Name:</strong>
                            <?php echo e($student->studname); ?>

                        </div>

                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong> Course: </strong>
                            <?php echo e($student->course); ?>

                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong> Fee: </strong>
                            <?php echo e($student->fee); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/syntaxer/Documents/Development/web/laravel/webcrud-master/resources/views/students/Show.blade.php ENDPATH**/ ?>