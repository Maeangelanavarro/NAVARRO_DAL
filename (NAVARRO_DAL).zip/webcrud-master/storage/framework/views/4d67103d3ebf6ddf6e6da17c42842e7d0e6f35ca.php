<?php $__env->startSection('content'); ?>

    <div class="col-md-6 offset-md-3 p-5">
        <div class="pull left">
            <h2 class="text-center"> Add new Team</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-warning" href="<?php echo e(route('students.index')); ?>">Go Back </a>
        </div>



        <div class="mt-5">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong> Whoops! </strong> There are problems with the detais you input. Please check again. <br> <br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erorr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <?php echo e($error); ?> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('students.store')); ?>" method="POST" class="mb-5">
                <?php echo csrf_field(); ?>

                <div clas="form-group">
                    <strong> Captain Name:</strong>
                    <input type="text" name="studname" class="form-control mb-2" placeholder="studname">
                    <strong> Course </strong>
                    <input type="text" name="course" class="form-control mb-2" placeholder="course">
                    <strong> Fee </strong>
                    <input type="text" name="fee" class="form-control mb-2" placeholder="fee">
                    <div class="float-right mt-3">
                        <button type="submit" class="btn btn-primary"> Submit </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/syntaxer/Documents/Development/web/laravel/webcrud-master/resources/views/students/Create.blade.php ENDPATH**/ ?>